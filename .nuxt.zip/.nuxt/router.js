import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from 'ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _45b2b592 = () => interopDefault(import('..\\pages\\feedback.vue' /* webpackChunkName: "pages/feedback" */))
const _5ecb9846 = () => interopDefault(import('..\\pages\\inspire.vue' /* webpackChunkName: "pages/inspire" */))
const _4f9a3dce = () => interopDefault(import('..\\pages\\package\\index.vue' /* webpackChunkName: "pages/package/index" */))
const _5d28796c = () => interopDefault(import('..\\pages\\service\\index.vue' /* webpackChunkName: "pages/service/index" */))
const _272bd04e = () => interopDefault(import('..\\pages\\package\\package-list.vue' /* webpackChunkName: "pages/package/package-list" */))
const _ab34fc58 = () => interopDefault(import('..\\pages\\service\\add-new-service.vue' /* webpackChunkName: "pages/service/add-new-service" */))
const _07300124 = () => interopDefault(import('..\\pages\\service\\service-list.vue' /* webpackChunkName: "pages/service/service-list" */))
const _6def547e = () => interopDefault(import('..\\pages\\package\\_id.vue' /* webpackChunkName: "pages/package/_id" */))
const _53ff0c95 = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages/index" */))

const emptyFn = () => {}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/feedback",
    component: _45b2b592,
    name: "feedback"
  }, {
    path: "/inspire",
    component: _5ecb9846,
    name: "inspire"
  }, {
    path: "/package",
    component: _4f9a3dce,
    name: "package"
  }, {
    path: "/service",
    component: _5d28796c,
    name: "service"
  }, {
    path: "/package/package-list",
    component: _272bd04e,
    name: "package-package-list"
  }, {
    path: "/service/add-new-service",
    component: _ab34fc58,
    name: "service-add-new-service"
  }, {
    path: "/service/service-list",
    component: _07300124,
    name: "service-service-list"
  }, {
    path: "/package/:id",
    component: _6def547e,
    name: "package-id"
  }, {
    path: "/",
    component: _53ff0c95,
    name: "index"
  }],

  fallback: false
}

export function createRouter (ssrContext, config) {
  const base = (config._app && config._app.basePath) || routerOptions.base
  const router = new Router({ ...routerOptions, base  })

  // TODO: remove in Nuxt 3
  const originalPush = router.push
  router.push = function push (location, onComplete = emptyFn, onAbort) {
    return originalPush.call(this, location, onComplete, onAbort)
  }

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    return resolve(to, current, append)
  }

  return router
}
