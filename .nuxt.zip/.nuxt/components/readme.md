# Discovered Components

This is an auto-generated list of components discovered by [nuxt/components](https://github.com/nuxt/components).

You can directly use them in pages and other components without the need to import them.

**Tip:** If a component is conditionally rendered with `v-if` and is big, it is better to use `Lazy` or `lazy-` prefix to lazy load.

- `<PackageGigsSection>` | `<package-gigs-section>` (components/package/gigsSection.vue)
- `<PackageSliderSection>` | `<package-slider-section>` (components/package/sliderSection.vue)
- `<ServiceCategoryList>` | `<service-category-list>` (components/service/categoryList.vue)
- `<ServiceCardGird>` | `<service-card-gird>` (components/service/serviceCardGird.vue)
- `<ServiceCardList>` | `<service-card-list>` (components/service/serviceCardList.vue)
- `<ServiceSubcategoryList>` | `<service-subcategory-list>` (components/service/subcategoryList.vue)
- `<ServiceSubsubcategoryList>` | `<service-subsubcategory-list>` (components/service/subsubcategoryList.vue)
- `<ServiceTextFields>` | `<service-text-fields>` (components/service/textFields.vue)
