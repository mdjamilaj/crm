import Vue from 'vue'
import { wrapFunctional } from './utils'

const components = {
  PackageGigsSection: () => import('../..\\components\\package\\gigsSection.vue' /* webpackChunkName: "components/package-gigs-section" */).then(c => wrapFunctional(c.default || c)),
  PackageSliderSection: () => import('../..\\components\\package\\sliderSection.vue' /* webpackChunkName: "components/package-slider-section" */).then(c => wrapFunctional(c.default || c)),
  ServiceCategoryList: () => import('../..\\components\\service\\categoryList.vue' /* webpackChunkName: "components/service-category-list" */).then(c => wrapFunctional(c.default || c)),
  ServiceCardGird: () => import('../..\\components\\service\\serviceCardGird.vue' /* webpackChunkName: "components/service-card-gird" */).then(c => wrapFunctional(c.default || c)),
  ServiceCardList: () => import('../..\\components\\service\\serviceCardList.vue' /* webpackChunkName: "components/service-card-list" */).then(c => wrapFunctional(c.default || c)),
  ServiceSubcategoryList: () => import('../..\\components\\service\\subcategoryList.vue' /* webpackChunkName: "components/service-subcategory-list" */).then(c => wrapFunctional(c.default || c)),
  ServiceSubsubcategoryList: () => import('../..\\components\\service\\subsubcategoryList.vue' /* webpackChunkName: "components/service-subsubcategory-list" */).then(c => wrapFunctional(c.default || c)),
  ServiceTextFields: () => import('../..\\components\\service\\textFields.vue' /* webpackChunkName: "components/service-text-fields" */).then(c => wrapFunctional(c.default || c))
}

for (const name in components) {
  Vue.component(name, components[name])
  Vue.component('Lazy' + name, components[name])
}
