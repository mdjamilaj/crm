import { wrapFunctional } from './utils'

export { default as PackageGigsSection } from '../..\\components\\package\\gigsSection.vue'
export { default as PackageSliderSection } from '../..\\components\\package\\sliderSection.vue'
export { default as ServiceCategoryList } from '../..\\components\\service\\categoryList.vue'
export { default as ServiceCardGird } from '../..\\components\\service\\serviceCardGird.vue'
export { default as ServiceCardList } from '../..\\components\\service\\serviceCardList.vue'
export { default as ServiceSubcategoryList } from '../..\\components\\service\\subcategoryList.vue'
export { default as ServiceSubsubcategoryList } from '../..\\components\\service\\subsubcategoryList.vue'
export { default as ServiceTextFields } from '../..\\components\\service\\textFields.vue'

export const LazyPackageGigsSection = import('../..\\components\\package\\gigsSection.vue' /* webpackChunkName: "components/package-gigs-section" */).then(c => wrapFunctional(c.default || c))
export const LazyPackageSliderSection = import('../..\\components\\package\\sliderSection.vue' /* webpackChunkName: "components/package-slider-section" */).then(c => wrapFunctional(c.default || c))
export const LazyServiceCategoryList = import('../..\\components\\service\\categoryList.vue' /* webpackChunkName: "components/service-category-list" */).then(c => wrapFunctional(c.default || c))
export const LazyServiceCardGird = import('../..\\components\\service\\serviceCardGird.vue' /* webpackChunkName: "components/service-card-gird" */).then(c => wrapFunctional(c.default || c))
export const LazyServiceCardList = import('../..\\components\\service\\serviceCardList.vue' /* webpackChunkName: "components/service-card-list" */).then(c => wrapFunctional(c.default || c))
export const LazyServiceSubcategoryList = import('../..\\components\\service\\subcategoryList.vue' /* webpackChunkName: "components/service-subcategory-list" */).then(c => wrapFunctional(c.default || c))
export const LazyServiceSubsubcategoryList = import('../..\\components\\service\\subsubcategoryList.vue' /* webpackChunkName: "components/service-subsubcategory-list" */).then(c => wrapFunctional(c.default || c))
export const LazyServiceTextFields = import('../..\\components\\service\\textFields.vue' /* webpackChunkName: "components/service-text-fields" */).then(c => wrapFunctional(c.default || c))
